package org.example.dto;

 import jakarta.persistence.Temporal;
 import jakarta.persistence.TemporalType;
 import lombok.Builder;
import lombok.Data;
import org.example.entities.ScriptType;

 import java.time.LocalDateTime;
 import java.util.Date;

@Data
@Builder
public class ResponseScriptDTO {
    private Long id;

    private String name;
    private String description;

    private String username;
    private String password;
    private String url;
    private ScriptType type;

    private Date  createAt;
}
