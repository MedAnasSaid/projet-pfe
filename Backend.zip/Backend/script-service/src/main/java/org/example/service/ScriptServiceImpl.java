package org.example.service;

import org.example.dto.RequestScriptDTO;
import org.example.dto.ResponseScriptDTO;
import org.example.entities.Script;
import org.example.mapper.ScriptMapper;
import org.example.repository.ScriptRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ScriptServiceImpl implements ScriptService{

    @Autowired
    private ScriptRepository scriptRepository;

    @Autowired
    private ScriptMapper scriptMapper;
    @Override
    public Long addScript(RequestScriptDTO requestScriptDTO) {
        Script script=scriptMapper.toScript(requestScriptDTO);
        return scriptRepository.save(script).getId();
    }

    @Override
    public List<ResponseScriptDTO> getAllScript() {
        List<Script> scriptList=scriptRepository.findAll();
        List<ResponseScriptDTO> scriptDTOS=scriptList.stream().map(scriptMapper::toScriptDTO).toList();

        return scriptDTOS;
    }

    @Override
    public ResponseScriptDTO getScriptById(Long id) {
        return null;
    }

    @Override
    public ResponseScriptDTO updateScript(Long id, RequestScriptDTO requestScriptDTO) {
        return null;
    }

    @Override
    public void deleteScript(Long id) {

    }
}
