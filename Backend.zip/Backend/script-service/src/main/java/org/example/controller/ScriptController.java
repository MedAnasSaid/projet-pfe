package org.example.controller;

import org.example.dto.RequestScriptDTO;
import org.example.dto.ResponseScriptDTO;
import org.example.service.ScriptService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/scripts")
@CrossOrigin("*")
public class ScriptController {
    @Autowired
    private ScriptService scriptService;

    @PostMapping("/add")
    ResponseEntity<Long> addScript(@RequestBody RequestScriptDTO scriptDTO) {
        return ResponseEntity.ok( scriptService.addScript(scriptDTO));
    }

    @GetMapping("/all")
    public  ResponseEntity<List<ResponseScriptDTO>> getAllProjects() {

        return ResponseEntity.ok(scriptService.getAllScript());
    }

}
