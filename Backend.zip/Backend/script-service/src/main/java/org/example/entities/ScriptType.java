package org.example.entities;


public enum ScriptType {
    JAR,
    PYTHON,
    SHELL,

}