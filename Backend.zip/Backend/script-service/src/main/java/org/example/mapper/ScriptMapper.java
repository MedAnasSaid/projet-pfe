package org.example.mapper;


import org.example.dto.RequestScriptDTO;
import org.example.dto.ResponseScriptDTO;
import org.example.entities.Script;
import org.springframework.stereotype.Service;

@Service
public class ScriptMapper {
    public Script toScript(RequestScriptDTO requestScriptDTO) {
        return Script.builder()
                .id(requestScriptDTO.getId())
                .name(requestScriptDTO.getName())
                .type(requestScriptDTO.getType())
                .username(requestScriptDTO.getUsername())
                .password(requestScriptDTO.getPassword())
                .url(requestScriptDTO.getUrl())
                .description(requestScriptDTO.getDescription())
                .build();
    }

    public ResponseScriptDTO toScriptDTO(Script script) {
        return ResponseScriptDTO.builder()
                .id(script.getId())
                .name(script.getName())
                .type(script.getType())
                .username(script.getUsername())
                .description(script.getDescription())
                 .build();
    }
}
