package org.example.service;

import org.example.dto.RequestScriptDTO;
import org.example.dto.ResponseScriptDTO;

import java.util.List;

public interface ScriptService {
    Long addScript(RequestScriptDTO requestScriptDTO);

    List<ResponseScriptDTO> getAllScript();

    ResponseScriptDTO getScriptById(Long id);

    ResponseScriptDTO updateScript(Long id, RequestScriptDTO requestScriptDTO);

    void deleteScript(Long id);
}

