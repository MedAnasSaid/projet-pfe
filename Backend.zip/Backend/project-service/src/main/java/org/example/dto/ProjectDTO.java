package org.example.dto;

import lombok.Builder;
import lombok.Data;

import java.util.Date;


@Data
@Builder
public class ProjectDTO {

    private Long id;
    private String name;

    private String description;

    private Date startDate;

    private Date endDate;
}
