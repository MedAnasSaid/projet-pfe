package org.example.service;

import org.example.dto.ProjectDTO;
import org.example.entities.Project;

import java.util.List;

public interface ProjectService {
    Long addProject(ProjectDTO project);

    List<ProjectDTO> getAllProjects();

    ProjectDTO getProjectById(Long id);

    Project updateProject(Long id, Project ProjectDTO);

    void deleteProject(Long id);
}
