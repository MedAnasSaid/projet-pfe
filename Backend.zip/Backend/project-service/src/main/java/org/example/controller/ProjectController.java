package org.example.controller;

import lombok.RequiredArgsConstructor;
import org.example.dto.ProjectDTO;
import org.example.entities.Project;
import org.example.service.ProjectService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/projects")
@CrossOrigin("*")
public class ProjectController {

    @Autowired
    private ProjectService projectService;

    @PostMapping("/add")
    ResponseEntity<Long> addProject(@RequestBody ProjectDTO projectDTO) {
        return ResponseEntity.ok( projectService.addProject(projectDTO));
    }

    @GetMapping("/all")
    public  ResponseEntity<List<ProjectDTO>> getAllProjects() {

        return ResponseEntity.ok(projectService.getAllProjects());
    }

    @GetMapping("/{id}")
    public ResponseEntity<ProjectDTO> getProjectById(@PathVariable Long id) {
        return ResponseEntity.ok( projectService.getProjectById(id));
    }

    @PutMapping("/update/{id}")
    public Project updateProject(@PathVariable Long id, @RequestBody Project project) {
        return projectService.updateProject(id, project);
    }

    @DeleteMapping("/delete/{id}")
    public void deleteProject(@PathVariable Long id) {
        projectService.deleteProject(id);
    }
}
