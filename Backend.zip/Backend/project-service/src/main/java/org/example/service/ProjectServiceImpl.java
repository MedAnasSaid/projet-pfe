package org.example.service;


import jakarta.persistence.EntityNotFoundException;
import org.example.dto.ProjectDTO;
import org.example.entities.Project;
import org.example.mapper.ProjectMapper;
import org.example.repository.ProjectRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
class ProjectServiceImpl implements ProjectService {

    @Autowired
    private ProjectRepository projectRepository;

    @Autowired
    private ProjectMapper projectMapper;


    @Override
    public Long addProject(ProjectDTO projectDTO) {
        Project project=projectMapper.toProject(projectDTO);
        return projectRepository.save(project).getId();
    }

    @Override
    public List<ProjectDTO> getAllProjects() {

        List<Project> projectList=projectRepository.findAll();
        List<ProjectDTO> projectDTOS=projectList.stream().map(projectMapper::toProjectDTO).toList();

        return projectDTOS;
    }

    @Override
    public ProjectDTO getProjectById(Long projectID) {
        return projectRepository.findById(projectID)
                .map(projectMapper::toProjectDTO)
                .orElseThrow(() -> new EntityNotFoundException("No project found with ID:: " + projectID));
    }

    @Override
    public Project updateProject(Long id, Project ProjectDTO) {
        return null;
    }


    @Override
    public void deleteProject(Long id) {

        projectRepository.deleteById(id);

    }
}
