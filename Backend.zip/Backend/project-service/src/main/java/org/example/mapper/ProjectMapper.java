package org.example.mapper;

  import org.example.dto.ProjectDTO;
  import org.example.entities.Project;
  import org.springframework.stereotype.Service;

@Service
public class ProjectMapper {
    public Project toProject(ProjectDTO projectDTO) {
        return Project.builder()
                .id(projectDTO.getId())
                .name(projectDTO.getName())
                .description(projectDTO.getDescription())
                .startDate(projectDTO.getStartDate())
                .endDate(projectDTO.getEndDate())
                .build();
    }

    public ProjectDTO toProjectDTO(Project project) {
        return ProjectDTO.builder()
                .id(project.getId())
                .name(project.getName())
                .description(project.getDescription())
                .startDate(project.getStartDate())
                .endDate(project.getEndDate()).build();


    }
}
