package org.example;

import org.example.ScriptApplication;
import org.example.dto.RegistrationRequest;
import org.example.entities.Role;
import org.example.repository.RoleRepository;
import org.example.repository.UserRepository;
import org.example.services.AuthenticationService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class SecurityApplication {

    public static void main(String[] args) {
        SpringApplication.run(ScriptApplication.class, args);
    }
     @Bean
     public CommandLineRunner runner(RoleRepository roleRepository, UserRepository userRepository, AuthenticationService authenticationService) {
         return args -> {
             System.out.println("Hello");
             if (roleRepository.findByName("ADMIN").isEmpty()) {
                 roleRepository.save(Role.builder().name("ADMIN").build());
             }
             if (roleRepository.findByName("USER").isEmpty()) {
                 roleRepository.save(Role.builder().name("USER").build());
             }
             if(!userRepository.findByEmail("admin@gmail.com").isEmpty()){
                 RegistrationRequest registrationRequest= RegistrationRequest.builder()
                         .email("admin@gmail.com")
                         .firstname("admin")
                         .lastname("admin")
                         .password("123456")
                         .build();
                 authenticationService.register(registrationRequest);
             }
         };
     }
}