import { Component, TemplateRef } from '@angular/core';
import { AppsService } from '../../../shared/services/apps.service';
import { NzModalService } from 'ng-zorro-antd/modal';
import { ProjectList } from '../../../shared/interfaces/project-list.type';
import { TableService } from '../../../shared/services/table.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ProjectService } from 'src/app/services/project.service';
import { Router } from '@angular/router';
import { NzMessageService } from 'ng-zorro-antd/message';
import { DatePipe } from '@angular/common';

@Component({
    templateUrl: './create-project.component.html',
    styleUrls:['./create-project.component.css']
})

export class CreateProjectComponent  {

    projectForm:FormGroup
    
    constructor (private projectListSvc: AppsService, private modalService: NzModalService,
         private tablesvc : TableService,private fb:FormBuilder,
         private message:NzMessageService,
        private router:Router,
        private datePipe: DatePipe,
        private projectService:ProjectService) {}

    ngOnInit(): void {

        this.projectForm=this.fb.group({
            name:['',Validators.required],
            description:['',Validators.required],
            startDate:['',Validators.required],
            endDate:['',Validators.required],

        })
         

       
    }

    onSubmit(){
        console.log(this.projectForm.value);
        console.log(this.datePipe.transform(this.projectForm.value.startDate, 'yyyy-MM-dd\'T\'HH:mm:ss\'Z\''))
        
        
        this.projectService.createProject({...this.projectForm.value,startDate:this.datePipe.transform(this.projectForm.value.startDate, 'yyyy-MM-dd\'T\'HH:mm:ss\'Z\''),endDate:this.datePipe.transform(this.projectForm.value.endDate, 'yyyy-MM-dd\'T\'HH:mm:ss\'Z\'')}).subscribe(res=>{
            this.message.success("Adeed with success")
            this.router.navigate(['/apps/projects/project-list'])
            
        })
    }

}