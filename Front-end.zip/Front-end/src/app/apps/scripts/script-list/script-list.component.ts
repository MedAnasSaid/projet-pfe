import { Component, OnInit } from '@angular/core';
import { ScriptService } from 'src/app/services/script.service';
import { TableService } from 'src/app/shared/services/table.service';

@Component({
  selector: 'app-script-list',
  templateUrl: './script-list.component.html',
  styleUrls: ['./script-list.component.css']
})
export class ScriptListComponent   {

 
  allChecked: boolean = false;
  indeterminate: boolean = false;
  displayData = [];
  searchInput: string
  scriptList:any=[]
   

   

  constructor(private tableSvc : TableService,private scriptService:ScriptService) {
       
  }

  search() {
      const data = this.scriptList
      this.displayData = this.tableSvc.search(this.searchInput, data )
  }
ngOnInit(): void {
   this.scriptService.getScripts().subscribe(res=>{
   
    this.displayData=res
    this.scriptList=res
    console.log(this.scriptList);
   })
  
}
}    