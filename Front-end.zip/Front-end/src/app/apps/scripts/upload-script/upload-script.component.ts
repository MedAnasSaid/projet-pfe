import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NzMessageService } from 'ng-zorro-antd/message';
import { NzModalService } from 'ng-zorro-antd/modal';
import { ScriptService } from 'src/app/services/script.service';
import { AppsService } from 'src/app/shared/services/apps.service';
import { TableService } from 'src/app/shared/services/table.service';

@Component({
  selector: 'app-upload-script',
  templateUrl: './upload-script.component.html',
  styleUrls: ['./upload-script.component.css']
})
export class UploadScriptComponent implements OnInit {

  scriptForm:FormGroup
  constructor (private projectListSvc: AppsService, private modalService: NzModalService, private tablesvc : TableService,
      private scriptService:ScriptService,
      private message:NzMessageService,
      private fb:FormBuilder,
      private router:Router
  ) {}

  ngOnInit(): void {

      this.scriptForm=this.fb.group({
          name:['',Validators.required],
          description:['',Validators.required],
          type:['',Validators.required],
          username:['',Validators.required],
          password:['',Validators.required],
          url:['',Validators.required]
          

      })
       

     
  }

  handleChange(e:any){

  }
  onSubmit(){
      console.log(this.scriptForm.value);
      
      this.scriptService.createScript(this.scriptForm.value).subscribe(res=>{
          this.message.success("Adeed with success")
          this.scriptForm.reset()
      })
  }

}