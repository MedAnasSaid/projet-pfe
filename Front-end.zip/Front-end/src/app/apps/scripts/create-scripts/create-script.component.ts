import { Component, TemplateRef } from '@angular/core';
import { AppsService } from '../../../shared/services/apps.service';
import { NzModalService } from 'ng-zorro-antd/modal';
import { ProjectList } from '../../../shared/interfaces/project-list.type';
import { TableService } from '../../../shared/services/table.service';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ScriptService } from 'src/app/services/script.service';
import { Router } from '@angular/router';
import { NzMessageService } from 'ng-zorro-antd/message';

@Component({
    templateUrl: './create-script.component.html',
    styleUrls:['./create-script.component.css']
})

export class CreateScriptComponent  {

    scriptForm:FormGroup
    constructor (private projectListSvc: AppsService, private modalService: NzModalService, private tablesvc : TableService,
        private scriptService:ScriptService,
        private message:NzMessageService,
        private fb:FormBuilder,
        private router:Router
    ) {}

    ngOnInit(): void {
 
        this.scriptForm=this.fb.group({
            name:['',Validators.required],
            description:['',Validators.required],
            type:['',Validators.required],
            username:['',Validators.required],
            password:['',Validators.required],
            url:['',Validators.required],
            items: this.fb.array([]) 
        })
    }

    onSubmit(){
        console.log(this.scriptForm.value);
        let data={
            description: "l,dsls",
            name: "ùlkdgokdjfk",
            password: ",smld,gdlm",
            type:"JAR",
            url:"ldf,glfd",
            username: "lsdg,f"
}
        
        this.scriptService.createScript(data).subscribe(res=>{
            this.message.success("Adeed with success")
            this.scriptForm.reset()
        })
    }

    get items() : FormArray {
        return this.scriptForm.get("items") as FormArray
      }
      newItem(): FormGroup {
        return this.fb.group({
          type: '',
          class: '',
          selector: '',
          value: ''
        })
     }
    addItems() {
        this.items.push(this.newItem());
     }
    
     removeItem(i:number) {
        this.items.removeAt(i);
      }
}