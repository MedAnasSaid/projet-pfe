import { NzCarouselModule } from 'ng-zorro-antd/carousel';
import { NzRadioModule } from 'ng-zorro-antd/radio';

export const moduleList = [ NzCarouselModule, NzRadioModule ];
