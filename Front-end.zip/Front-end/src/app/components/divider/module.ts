import { NzDividerModule } from 'ng-zorro-antd/divider';

export const moduleList = [ NzDividerModule ];
