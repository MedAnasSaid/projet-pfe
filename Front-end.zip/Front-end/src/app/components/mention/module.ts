import { NzMentionModule } from 'ng-zorro-antd/mention';
import { NzAvatarModule } from 'ng-zorro-antd/avatar';
import { NzFormModule } from 'ng-zorro-antd/form';
import { NzInputModule } from 'ng-zorro-antd/input';
import { NzTabsModule } from 'ng-zorro-antd/tabs';
import { NzButtonModule } from 'ng-zorro-antd/button';

export const moduleList = [ NzMentionModule, NzAvatarModule, NzFormModule, NzInputModule, NzTabsModule, NzButtonModule ];
