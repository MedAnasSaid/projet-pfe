import { NzInputNumberModule } from 'ng-zorro-antd/input-number';
import { NzButtonModule } from 'ng-zorro-antd/button';

export const moduleList = [ NzInputNumberModule, NzButtonModule ];
