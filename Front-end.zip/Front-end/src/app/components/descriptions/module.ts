import { NzDescriptionsModule } from 'ng-zorro-antd/descriptions';
import { NzBadgeModule } from 'ng-zorro-antd/badge';
import { NzRadioModule } from 'ng-zorro-antd/radio';

export const moduleList = [ NzDescriptionsModule, NzBadgeModule, NzRadioModule ];
