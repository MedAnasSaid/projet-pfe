import { Component } from '@angular/core'
import { FormBuilder, FormGroup,  Validators } from '@angular/forms';
import { AuthService } from 'src/app/services/auth.service';


@Component({
    templateUrl: './login-2.component.html',
    styleUrls:['./login.component.css']
})

export class Login2Component {
    loginForm: FormGroup;

 

    submitForm(): void {
        for (const i in this.loginForm.controls) {
            this.loginForm.controls[ i ].markAsDirty();
            this.loginForm.controls[ i ].updateValueAndValidity();
        }

        console.log(this.loginForm.value);

        this.authService.login(this.loginForm.value).subscribe(res=>{
            
        })
        
    }

    constructor(private fb: FormBuilder,private authService:AuthService) {
    }

    ngOnInit(): void {
        this.loginForm = this.fb.group({
            email: [ null, [ Validators.required ] ],
            password: [ null, [ Validators.required ] ]
        });
    }
}    